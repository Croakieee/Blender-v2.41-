This folder is for automatically saved scripts configuration data.

To use this feature scripts just need to set a proper Blender.Registry key.

To know more, check the API Reference doc (specifically the API_related and
Registry parts) and the documentation for the "Scripts Config Editor" script.
